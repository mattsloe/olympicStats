//
//  input.h
//  olympicStats
//
//  Created by Matt Loera on 2/28/22.
//

#ifndef input_h
#define input_h
int getIntInput(const std::string& prompt);
void getStringInput(const std::string& prompt,std::string& inString);

#endif /* input_h */
