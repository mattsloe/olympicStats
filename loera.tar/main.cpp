//main driver for olympicStats program
//Author: Matt Loera
//
#include "test.h"
int main()
{
  testSport();
  return 0;
}
