//main driver for olympicStats program
//Author: Matt Loera
//
#include "test.h"
int main()
{
  testSub1();
  return 0;
}
