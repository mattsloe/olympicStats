//
//  Athlete_Tree.h
//  olympicStats

//  A balanced tree implementation for holding Athletes

//  Created by Matt Loera on 2/23/22.
//

#ifndef Athlete_Tree_h
#define Athlete_Tree_h
class Athlete;

class Athlete_Tree
{
public:
  
private:
  
  
};

#endif /* Athlete_Tree_h */
